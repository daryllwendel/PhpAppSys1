<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/CustomerHotOrder-display.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
     <div class="customerhot-container1">
        <div class="product-grid1">
          <?php $__currentLoopData = $mydesign2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-card1">
                <div class="product-image1">
                    <div class="placeholder-image1">
                      <img src="<?php echo e(asset('storage/' . $item->productImg)); ?>" alt="">
                    </div>
                    <?php
                      $item2 = $selectAll[$index] ?? null;
                    ?>
                    <?php if($item2 && $item2->customerId != null): ?>
                        <div class="special-tag1">New Ready-to-Print!</div>
                    <?php else: ?>
                        <div class="special-tag1">Customer-requested!</div>
                    <?php endif; ?>
                    
                </div>
                <div class="product-info1">
                    <div class="product-number1"><?php echo e($item->name); ?></div>
                    <button class="buy-button1"
                    data-id2="<?php echo e($item->productId); ?>" 
                    data-name2="<?php echo e($item->name); ?>" 
                    data-price2="<?php echo e($item->price); ?>" 
                    data-type2="<?php echo e($item->type); ?>" 
                    data-printtype2="<?php echo e($item->printType); ?>" 
                    data-img2="<?php echo e(asset('storage/' . $item->productImg)); ?>"
                    data-status2="<?php echo e($item->status); ?>"
                    >Buy</button>
                </div>
            </div>    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

      <div class="overlay" id="overlay">
  <div class="product-modal" id="product-modal">
      <form action="/addtocart" method="POST" class="hotdesigncart">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="customerId" value="<?php echo e(Auth::id()); ?>">
        <input type="hidden" name="productId" id="productId" >
        <input type="hidden" name="price" id="productPrice2">

          <button type="button" class="close-btn" aria-label="Close" id="close-btn">×</button>
          <div class="modal-header" name="product_name">Black and Yellow Gaming Sports Jersey</div>
          
          <img src="<?php echo e(asset('storage/product-image.jpg')); ?>" alt="Black and Yellow Gaming Sports Jersey" class="product-image" id="product-image2">
          
          <div class="product-info">
              <div class="price" id="price2"></div>
          </div>
          
          <div class="button-container">
              <button type="submit" class="add-to-cart-btn">Add to cart</button>
          </div>
      </form>
  </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\Asus\Documents\GitHub\PhpAppSys\clothingsm\resources\views/CustomerHotOrder-display.blade.php ENDPATH**/ ?>