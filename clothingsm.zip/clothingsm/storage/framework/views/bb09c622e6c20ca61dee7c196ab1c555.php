<!DOCTYPE html>
<html>
<head>
    <title>Your OTP</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP is: <strong><?php echo e($otp); ?></strong></p>
    <p>Please use this within 5 minutes.</p>
</body>
</html>
<?php /**PATH C:\Users\Asus\Documents\GitHub\PhpAppSys\clothingsm\resources\views/emails/otp.blade.php ENDPATH**/ ?>