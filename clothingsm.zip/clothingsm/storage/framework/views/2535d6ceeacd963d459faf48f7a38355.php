<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/CustomerAddtoCart.css')); ?>">
    <script src="<?php echo e(asset('js/customerJS.js')); ?>"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=close" />
    <title>Shopping Cart</title>
</head>
<body>
    <div class="shopping-cart">
        <div class="shopping-cart-container">
            <div class="shopping-cart-header">
                <span class="material-symbols-outlined" id="back">close</span>
                <p>Your Cart</p>
            </div>
            <?php if(isset($order_items) && $order_items->count() > 0): ?>
                <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="shopping-cart-item" data-productid="<?php echo e($item->product_id); ?>">
                        <input type="hidden" name="product_id" value="<?php echo e($item->product_id); ?>" class="product_id" id="product_id">
                        <div class="shopping-cart-item-image">
                            <img src="<?php echo e(asset('storage/' . $item->productImg)); ?>" alt="Black and Yellow Gaming Jersey">
                        </div>
                        <div class="shopping-cart-item-details">
                            <h3 class="shopping-cart-item-title"><?php echo e($item->name); ?></h3>
                            <span class="shopping-cart-item-tag"><?php echo e($item->type); ?></span>
                            <div class="shopping-cart-item-sizes">
                                <?php
                                    $sizes = App\Models\ProductSize::where('product_id', $item->product_id)->get();
                                ?>
                            Sizes:
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="size-badge"><?php echo e($size->size); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="shopping-cart-item-price">Price: ₱ <?php echo e($item->price); ?></div>
                        </div>

                        <div class="shopping-cart-quantity-selector">
                            <?php
                                    $sizes = App\Models\ProductSize::where('product_id', $item->product_id)->get();
                                ?>
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="shopping-cart-size-row">
                                    <span class="shopping-cart-size-label"><?php echo e($items->size); ?></span>
                                    <div class="shopping-cart-quantity-control">
                                        <button type="button" class="shopping-cart-quantity-btn minus">-</button>
                                        <input
                                            type="text"
                                            name="set[<?php echo e($item->product_id); ?>][<?php echo e($items->size); ?>]"
                                            class="shopping-cart-quantity-input"
                                            value="0"
                                            data-price="<?php echo e($item->price); ?>">
                                        <button type="button" class="shopping-cart-quantity-btn plus">+</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <form action="/deletecart" class="deletecart" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="productId" value="<?php echo e($item->product_id); ?>">
                        <button class="shopping-cart-remove-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                        </button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="shopping-cart-footer">
                    <button class="shopping-cart-checkout-btn" id="checkout-btn">Proceed to Checkout</button>
                    <div class="shopping-cart-total">
                        <span>Total:</span>
                        <span id="cart-total">₱0.00</span>
                    </div>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 0;">
                    <h2>Oops, Your Cart is Empty</h2>
                    <button class="shopping-cart-checkout-btn" id="back1" style="margin-top: 20px;">Back</button>
                </div>
            <?php endif; ?>
        </div>
    </div>
 
    <div class="checkout-form" id="checkout-form">
        <h2>Checkout</h2>

        <div class="checkout-container-layout">
            <div class="shipping-details">
                <form action="/checkout" class="checkout" method="POST" id="checkout-form" onclick="return addresscheck()">
                    <?php echo csrf_field(); ?>
                    <h3>Shipping Information</h3>

                    <label for="recipient">Recipient</label><br>
                    <div class="form-group">
                        <label for="recipient">Recipient Name</label>
                        <input type="text" id="recipient" name="recipient" value="<?php echo e(Auth::user()->name); ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="contact">Contact Number:</label>
                        <input type="text" id="contact" name="contact" value="<?php echo e(Auth::user()->mobile_number); ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                    </div>
                    <div class="form-group">
                        <label for="subtotal">Province:</label>
                        <input type="text" id="province" name="province" value="<?php echo e(Auth::user()->Province); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group">
                        <label for="city">City:</label>
                        <input type="text" id="city" name="city" class="form-control" value="<?php echo e(Auth::user()->City); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="barangay">Barangay:</label>
                        <input type="text" id="barangay" name="barangay" class="form-control" value="<?php echo e(Auth::user()->Baranggay); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="purok">Purok:</label>
                        <input type="text" id="purok" name="purok" class="form-control" value="<?php echo e(Auth::user()->Purok); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="subtotal">ZipCode:</label>
                        <input type="text" id="zipcode" name="zipcode" value="<?php echo e(Auth::user()->ZipCode); ?>" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="subtotal">Sub-total:</label>
                        <span id="cart-total1">₱0.00</span>
                    </div>

                    <div class="form-group">
                        <label for="payment">Payment Option:</label>
                        <select id="payment" name="payment_method" class="form-control" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $paymentname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                name="<?php echo e($item->paymentMethodId); ?>"
                                value="<?php echo e($item->paymentMethodId); ?>"
                                data-charge="<?php echo e($item->charge); ?>"
                                data-number=<?php echo e($item->number); ?>

                                data-bankName=<?php echo e($item->bankName); ?>

                                data-name=<?php echo e($item->name); ?>>
                                <?php echo e($item->paymentName); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group" id="bank-details" style="display: none;">
                        <label for="names">Name:</label>
                        <input type="text" id="name" name="name" class="form-control" readonly>
                        <label for="bank-name">Bank Name:</label>
                        <input type="text" id="bank-name" name="bank_name" class="form-control" readonly>
                        <label for="numbers">Number:</label>
                        <input type="text" id="number" name="number" class="form-control" readonly>
                    </div>

                    <div class="form-group" id="gcash-details" style="display: none;">
                        <label for="gcash-number">Gcash Number:</label>
                        <input type="text" id="gcash-number" name="gcash_number" class="form-control" readonly>
                        <label for="gcash-name">Gcash Name:</label>
                        <input type="text" id="gcash-name" name="gcash_name" class="form-control" readonly>
                    </div>

                    <div class="form-group">
                        <label for="charge">Charge:</label>
                        <span id="charge-total">₱0.00</span>
                    </div>

                    <div class="form-group">
                        <label for="grand-total">Grand Total:</label>
                        <input type="text" id="grand-total" name="grand_total" value="<SUBTOTAL + CHARGE>" class="form-control" readonly>
                    </div>

                    <div class="checkout-buttons">
                        <button type="submit" class="order-btn">Order</button>
                        <button type="button" class="cancel-btn" id="cancel-btn">Cancel</button>
                    </div>

                    <!-- Hidden inputs for order items data -->
                    <input type="hidden" id="order-items-data" name="order_items" value="">

            </div>

            <div class="order-summary">
                <h3>Order Summary</h3>
                <div class="order-items" id="checkout-items-container">
                    <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $sizes = App\Models\ProductSize::where('product_id', $item->product_id)->get();
                        ?>
                        <div class="order-item" data-productid="<?php echo e($item->product_id); ?>">
                            <div class="order-item-details">
                                <input type="hidden" name="productId1" value="<?php echo e($item->product_id); ?>">
                                <img src="<?php echo e(asset('storage/' . $item->productImg)); ?>" alt="">
                                <span class="order-item-name1"><?php echo e($item->name); ?></span>
                                <span class="order-item-type1"><?php echo e($item->type); ?></span>
                                <div>
                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="size-badge"><?php echo e($size->size); ?></span>
                                        <span class="quantity-size" data-size="<?php echo e($size->size); ?>"></span><br>
                                        <span class="total-price" data-size="<?php echo e($size->size); ?>" data-price="<?php echo e($item->price); ?>"></span><br>
                                        <input type="hidden" name="quantity1[<?php echo e($item->product_id); ?>][<?php echo e($size->size); ?>]" id="quantity1" value="">
                                        <input type="hidden" name="price1[<?php echo e($item->product_id); ?>][<?php echo e($item->price); ?>]" id="price1" value="">
                                        <input type="hidden" name="size1[<?php echo e($item->product_id); ?>][<?php echo e($size->size); ?>]" id="size1" value="<?php echo e($size->size); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="order-total">
                    <h4>Sub-Total: ₱ <span id="checkout-subtotal">0.00</span></h4>
                </div>
            </div>
        </form>
        </div>
    </div>
     <div class="confirmation-container" >
        <div class="floating-elements">
            <div class="floating-bag">👜</div>
            <div class="floating-crown">👑</div>
            <div class="floating-time">⏰</div>
            <div class="floating-coin">🪙</div>
        </div>

        <div class="success-icon">
            <div class="cart-icon"></div>
        </div>

        <h1 class="confirmation-title">Your Order has been submitted for approval!</h1>

        <p class="confirmation-message">
            Hang tight! We're reviewing your order and will send you a confirmation shortly.<br><br>
            Please wait while we review your order. A confirmation email or SMS will be sent once your order is approved and ready for shipping.
        </p>


        <div class="action-buttons">
            <a href="#" class="btn-primary">See My Orders</a>
            <a href="#" class="btn-secondary">Back to Home</a>
        </div>
    </div>
    <script>const currentCustomerId = <?php echo e(Auth::id()); ?>;</script>
    <script src="<?php echo e(asset('js/customerJS.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\Asus\Documents\GitHub\PhpAppSys\clothingsm\resources\views/CustomerAddtoCart.blade.php ENDPATH**/ ?>