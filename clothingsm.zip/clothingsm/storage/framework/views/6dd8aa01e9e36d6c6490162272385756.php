<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/CustomerMyDesignOrder-display.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <div class="customerhot-container">
        <div class="product-grid">
            <?php $__currentLoopData = $mydesign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card">
                    <div class="product-image">
                        <div class="placeholder-image">
                            <img src="<?php echo e(asset('storage/' . $item->productImg)); ?>" alt="">
                        </div>
                        <div class="special-tag">Customer-requested!</div>
                    </div>
                    <div class="product-info">
                        <div class="product-number"><?php echo e($item->name); ?></div>
                        <?php if($item->viewStatus == 'pending'): ?>
                            <p>This product is pending for approval</p>
                        <?php elseif($item->viewStatus == 'approved'): ?>
                            <button class="buy-button" data-id1="<?php echo e($item->productId); ?>"
                                data-name1="<?php echo e($item->name); ?>" data-price1="<?php echo e($item->price); ?>"
                                data-type1="<?php echo e($item->type); ?>" data-printtype1="<?php echo e($item->printType); ?>"
                                data-img1="<?php echo e(asset('storage/' . $item->productImg)); ?>"
                                data-status1="<?php echo e($item->status); ?>">Buy</button>
                        <?php endif; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="overlay" id="overlay">
        <div class="product-modal" id="product-modal">
            <form action="/addtocart" method="POST" class="mydesigncart">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="customerId" value="<?php echo e(Auth::id()); ?>">
                <input type="hidden" name="productId" id="productId">
                <input type="hidden" name="price" id="productPrice1">

                <button type="button" class="close-btn" aria-label="Close" id="close-btn">×</button>
                <div class="modal-header" name="product_name">Black and Yellow Gaming Sports Jersey</div>

                <img src="<?php echo e(asset('storage/product-image.jpg')); ?>" alt="Black and Yellow Gaming Sports Jersey"
                    class="product-image" id="product-image1">

                <div class="product-info">
                    <div class="price" id="price1"></div>
                </div>

                <div class="button-container">
                    <button type="submit" class="add-to-cart-btn">Add to cart</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\Asus\Documents\GitHub\PhpAppSys\clothingsm\resources\views/CustomerMyDesignOrder-display.blade.php ENDPATH**/ ?>